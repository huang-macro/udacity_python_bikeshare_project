Udacity Python programing project: Exploring the US Bikeshare data

I have completed the project without any external resources other than websites that are open for public use, such as StackOverflow. 